from flask import Flask, render_template, request
import pickle
import numpy as np

# Load the KNN model
filename = 'heart-disease-prediction-knn-model.pkl'
model = pickle.load(open(filename, 'rb'))

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('main.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Collecting inputs from the form
        age = int(request.form['age'])
        sex = int(request.form['sex'])
        cp = int(request.form['cp'])
        
        # Handling trestbps input
        trestbps_input = request.form['trestbps']
        if '-' in trestbps_input:
            trestbps_range = trestbps_input.split('-')
            try:
                trestbps = (int(trestbps_range[0]) + int(trestbps_range[1])) // 2
            except ValueError:
                return render_template('error.html', message="Invalid input for trestbps. Please provide a valid number or range.")
        else:
            try:
                trestbps = int(trestbps_input)
            except ValueError:
                return render_template('error.html', message="Invalid input for trestbps. Please provide a valid number.")
        
        # Handling chol input
        chol_input = request.form['chol']
        if '-' in chol_input:
            chol_range = chol_input.split('-')
            try:
                chol = (int(chol_range[0]) + int(chol_range[1])) // 2
            except ValueError:
                return render_template('error.html', message="Invalid input for chol. Please provide a valid number or range.")
        else:
            try:
                chol = int(chol_input)
            except ValueError:
                return render_template('error.html', message="Invalid input for chol. Please provide a valid number.")
        
        # Handling thalach input
        thalach_input = request.form['thalach']
        if '-' in thalach_input:
            thalach_range = thalach_input.split('-')
            try:
                thalach = (int(thalach_range[0]) + int(thalach_range[1])) // 2
            except ValueError:
                return render_template('error.html', message="Invalid input for thalach. Please provide a valid number or range.")
        else:
            try:
                thalach = int(thalach_input)
            except ValueError:
                return render_template('error.html', message="Invalid input for thalach. Please provide a valid number.")
        
        # Continue with other fields
        fbs = int(request.form['fbs'])
        restecg = int(request.form['restecg'])
        exang = int(request.form['exang'])
        oldpeak = float(request.form['oldpeak'])
        slope = int(request.form['slope'])
        ca = int(request.form['ca'])
        thal = int(request.form['thal'])
        
        # Creating a numpy array with the input data
        data = np.array([[age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]])
        
        # Making prediction using the loaded model
        my_prediction = model.predict(data)
        
        return render_template('result.html', prediction=my_prediction)



if __name__ == '__main__':
    app.run(debug=True)
